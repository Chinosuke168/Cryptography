package main
import (
	"fmt"
)
func main() {
	fmt.Println("The answer is: cryptoCTF{meowmeow}")
}