# Cryptography# Crypto_CADT

cd D:/CADT/Year3/Cryptography/week3

# how to run from lab0-4
go run lab0.go

go run lab1.go

go run lab2.go

go run lab3.go

go run lab4.go


# Push to github
cd Cryptography
git init 
git add .
git commit -m "add"
git remote add origin https://github.com/Chinosuke168/Cryptography
git branch -M main
git pull origin main --rebase
git push -u origin main
